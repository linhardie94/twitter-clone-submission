// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCibmCXL-3FeYP908HYWvaQvYEqFtZmm9o",
  authDomain: "twitter-clone-c1477.firebaseapp.com",
  projectId: "twitter-clone-c1477",
  storageBucket: "twitter-clone-c1477.appspot.com",
  messagingSenderId: "862822985432",
  appId: "1:862822985432:web:86de84c47a438a9d0671ad"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;